import { useEffect, useState } from "react";

export default function StudentGrades(){

  const student_id = 1;

  const [grades,setGrades] = useState([]);
  const [summary,setSummary] = useState({
    cgpa:0,
    earned_credits:0,
    arrears:0
  });

  const [category,setCategory] = useState([]);
  const [loading,setLoading] = useState(true);

  const loadGrades = async ()=>{
    try{
      let res = await fetch(
        `http://localhost/SmartCampus/backend/get_student_grades.php?student_id=${student_id}`
      );

      let data = await res.json();

      if(data.status){
        setGrades(data.grades);
        setSummary(data.summary);
        setCategory(data.category);
      }

    }catch(e){
      console.log(e);
    }

    setLoading(false);
  };

  useEffect(()=>{ loadGrades(); },[]);

  return(
    <div className="container mt-4">

      <div className="card p-4 shadow">

        <h3>Grade Details</h3>
        <p className="text-secondary">
          View your semester-wise grades and earned credits
        </p>

        <hr/>

        {loading && <h5>Loading...</h5>}

        {!loading && (
          <>
            {/* CGPA SUMMARY */}
            <div className="row text-center mb-4">

              <div className="col-md-4">
                <div className="card p-3 shadow">
                  <h6>CGPA</h6>
                  <h2>{summary.cgpa}</h2>
                </div>
              </div>

              <div className="col-md-4">
                <div className="card p-3 shadow text-success">
                  <h6>Earned Credits</h6>
                  <h2>{summary.earned_credits}</h2>
                </div>
              </div>

              <div className="col-md-4">
                <div className="card p-3 shadow text-danger">
                  <h6>No of Arrears</h6>
                  <h2>{summary.arrears}</h2>
                </div>
              </div>

            </div>

            {/* GRADES TABLE */}
            <table className="table table-bordered">
              <thead style={{background:"#0d6efd", color:"white"}}>
                <tr>
                  <th>Semester</th>
                  <th>Course Code</th>
                  <th>Course Name</th>
                  <th>Credits</th>
                  <th>Grade</th>
                  <th>Category</th>
                  <th>Year of Passing</th>
                </tr>
              </thead>

              <tbody>

                {grades.map((g,i)=>(
                  <tr key={i}>
                    <td>{g.sem}</td>
                    <td>{g.course_code}</td>
                    <td>{g.course_name}</td>
                    <td>{g.credits}</td>
                    <td><b>{g.grade}</b></td>
                    <td>{g.category}</td>
                    <td>{g.year}</td>
                  </tr>
                ))}

                {grades.length===0 && (
                  <tr>
                    <td colSpan="7" className="text-center">
                      No Grade Records Found
                    </td>
                  </tr>
                )}

              </tbody>
            </table>

            <hr/>

            {/* CATEGORY SUMMARY TABLE */}
            <h5>Category Wise Credit Summary</h5>

            <table className="table table-bordered">
              <thead className="table-light">
                <tr>
                  <th>Category</th>
                  <th>Minimum Credit Requirement</th>
                  <th>Credits Studied</th>
                  <th>Credits Earned</th>
                  <th>Credits To Be Earned</th>
                </tr>
              </thead>

              <tbody>

                {category.map((c,i)=>(
                  <tr key={i}>
                    <td>{c.category}</td>
                    <td>{c.min_required}</td>
                    <td>{c.studied}</td>
                    <td>{c.earned}</td>
                    <td>{c.remaining}</td>
                  </tr>
                ))}

                {category.length === 0 && (
                  <tr>
                    <td colSpan="5" className="text-center">
                      No Category Data Found
                    </td>
                  </tr>
                )}

              </tbody>
            </table>

          </>
        )}

      </div>

    </div>
  );
}
