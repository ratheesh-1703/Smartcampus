import { useEffect } from "react";

export default function StudentDashboard() {

  // ✅ GET USER FROM STORAGE
  const user = JSON.parse(localStorage.getItem("user"));

  // ✅ ALWAYS RESOLVE STUDENT ID CORRECTLY
  const student_id =
    user?.student_id ||
    user?.linked_id ||
    user?.user_id;

  useEffect(() => {

    // ❌ SAFETY CHECK
    if (!student_id) {
      console.error("❌ Student ID not found");
      return;
    }

    // ❌ BROWSER CHECK
    if (!navigator.geolocation) {
      console.error("❌ Geolocation not supported");
      return;
    }

    console.log("✅ Live location tracking started");

    // ✅ SEND LOCATION TO BACKEND
    const sendLocation = async (lat, lng) => {
      try {
        await fetch(
          "http://localhost/SmartCampus/backend/update_location.php",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              student_id: student_id,
              latitude: lat,
              longitude: lng
            })
          }
        );

        console.log("📍 Location sent:", lat, lng);

      } catch (err) {
        console.error("❌ Location send failed", err);
      }
    };

    // ✅ WATCH GPS POSITION
    const watchId = navigator.geolocation.watchPosition(

      // SUCCESS
      (position) => {
        const { latitude, longitude } = position.coords;
        console.log("📡 GPS OK:", latitude, longitude);
        sendLocation(latitude, longitude);
      },

      // ERROR
      (error) => {
        console.error("❌ GPS Error:", error.message);
      },

      // OPTIONS
      {
        enableHighAccuracy: true,
        timeout: 20000,
        maximumAge: 0
      }
    );

    // CLEANUP
    return () => navigator.geolocation.clearWatch(watchId);

  }, [student_id]);

  // ✅ SIMPLE, CLEAN UI (NO CONFUSION)
  return (
    <div className="container mt-4">
      <div className="card p-4 shadow">
        <h3>Student Dashboard</h3>
        <p className="text-success">
          Live Location Tracking Enabled ✔
        </p>
        <p className="text-muted">
          Your location is securely shared while you are on campus.
        </p>
      </div>
    </div>
  );
}
