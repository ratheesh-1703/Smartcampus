import { useEffect, useState } from "react";

export default function HODStudents() {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    fetch("http://localhost/SmartCampus/backend/get_students.php")
      .then(res => res.json())
      .then(data => {
        if (data.status) setStudents(data.students);
      });
  }, []);

  return (
    <div className="container mt-4">
      <h3>Department Students</h3>

      <table className="table table-striped mt-3">
        <thead className="table-dark">
          <tr>
            <th>Name</th>
            <th>Register No</th>
            <th>Year</th>
          </tr>
        </thead>
        <tbody>
          {students.map(s => (
            <tr key={s.id}>
              <td>{s.name}</td>
              <td>{s.reg_no}</td>
              <td>{s.year}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
