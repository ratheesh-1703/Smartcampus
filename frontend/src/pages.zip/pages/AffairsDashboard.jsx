import { useState } from "react";
import { Link } from "react-router-dom";

export default function AffairsDashboard() {

  const [menuOpen,setMenuOpen] = useState(true);

  return(
    <div className="d-flex" style={{height:"100vh"}}>

      {/* Sidebar */}
      <div style={{
        width: menuOpen ? "260px":"0px",
        overflow:"hidden",
        background:"#6f42c1",
        color:"white",
        padding:"15px",
        transition:"0.3s"
      }}>
        <h4 className="text-center">Student Affairs</h4>

        <ul className="nav flex-column mt-3">

          <li className="nav-item">
            <Link className="nav-link text-white" to="/affairs">
              Dashboard
            </Link>
          </li>

          <li className="nav-item">
            <Link className="nav-link text-white" to="/affairs/sos">
              SOS Alerts
            </Link>
          </li>

          <li className="nav-item">
            <Link className="nav-link text-white" to="/affairs/location">
              Live Student Location
            </Link>
          </li>

          <li className="nav-item mt-3">
            <a className="btn btn-danger w-100" href="/">
              Logout
            </a>
          </li>

        </ul>
      </div>

      {/* Main Section */}
      <div className="flex-grow-1">

        <div className="p-3 shadow d-flex justify-content-between align-items-center">
          <h4>Student Affairs Dashboard</h4>

          <button
            className="btn btn-outline-light"
            onClick={()=>setMenuOpen(!menuOpen)}
          >
            ☰
          </button>
        </div>

        <div className="p-4">
          <div className="card p-4 shadow">
            <h3>Welcome Student Affairs Officer</h3>
            <p>You can monitor student SOS alerts and live locations here.</p>
          </div>
        </div>

      </div>

    </div>
  );
}
