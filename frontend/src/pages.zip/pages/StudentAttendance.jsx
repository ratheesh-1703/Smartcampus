import { useState, useEffect } from "react";

export default function StudentAttendance(){

  const student_id = 1; // later from login
  const [msg,setMsg] = useState("");

  const markAttendance = async ()=>{
    
    setMsg("Checking...");

    let res = await fetch(
      "http://localhost/SmartCampus/backend/student_mark_attendance.php",
      {
        method:"POST",
        headers:{ "Content-Type":"application/json"},
        body: JSON.stringify({ student_id })
      }
    );

    let data = await res.json();
    setMsg(data.message);
  };

  return(
    <div className="container mt-5">
      
      <div className="card p-4 shadow text-center">

        <h3>Student Attendance</h3>
        <p>Click the button to mark your attendance</p>

        <button className="btn btn-success" onClick={markAttendance}>
          Mark Attendance
        </button>

        <p className="mt-3 text-primary">{msg}</p>

      </div>

    </div>
  );
}
