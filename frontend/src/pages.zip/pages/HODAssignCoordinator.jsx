import { useEffect, useState } from "react";

export default function HODAssignCoordinator(){

  const user = JSON.parse(localStorage.getItem("user"));
  const hodTeacherId = user?.linked_id;

  const [teachers, setTeachers] = useState([]);
  const [className, setClassName] = useState("");
  const [msg, setMsg] = useState("");

  const loadTeachers = async () => {
    const res = await fetch(
      "http://localhost/SmartCampus/backend/get_hod_teachers.php",
      {
        method: "POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({ teacher_id: hodTeacherId })
      }
    );
    const data = await res.json();
    if(data.status){
      setTeachers(data.teachers);
    }
  };

  const assignCoordinator = async (teacher_id) => {
    if(!className){
      alert("Enter class name");
      return;
    }

    const res = await fetch(
      "http://localhost/SmartCampus/backend/assign_coordinator.php",
      {
        method: "POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({
          teacher_id,
          class_name: className
        })
      }
    );

    const data = await res.json();
    if(data.status){
      setMsg("✅ Coordinator Assigned");
      setClassName("");
      loadTeachers();
    }else{
      setMsg("❌ " + data.message);
    }
  };

  useEffect(()=>{
    loadTeachers();
  },[]);

  return (
    <div className="container mt-4">
      <h3>Assign Class Coordinator</h3>

      {msg && <p className="fw-bold">{msg}</p>}

      <input
        className="form-control mb-3"
        placeholder="Class (e.g. BSc IT - II A)"
        value={className}
        onChange={e=>setClassName(e.target.value)}
      />

      <table className="table table-bordered">
        <thead className="table-dark">
          <tr>
            <th>Name</th>
            <th>Department</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
          {teachers.map(t=>(
            <tr key={t.id}>
              <td>{t.name}</td>
              <td>{t.dept}</td>
              <td>
                {t.is_coordinator == 1
                  ? <span className="badge bg-success">Coordinator</span>
                  : <span className="badge bg-secondary">Teacher</span>}
              </td>
              <td>
                {t.is_coordinator == 0 && (
                  <button
                    className="btn btn-sm btn-primary"
                    onClick={()=>assignCoordinator(t.id)}
                  >
                    Assign
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>

      </table>
    </div>
  );
}
