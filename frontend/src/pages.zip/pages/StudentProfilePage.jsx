import { useEffect, useState } from "react";

export default function StudentProfilePage(){

  const student_id = 1; // later set dynamically after login
  const [s,setS] = useState(null);

  const loadProfile = async ()=>{
    let res = await fetch(
      `http://localhost/SmartCampus/backend/get_student_profile_portal.php?student_id=${student_id}`
    );

    let data = await res.json();

    if(data.status){
      setS(data.student);
    }
  };

  useEffect(()=>{ loadProfile(); },[]);

  if(!s) return <h3 className="m-4">Loading Profile...</h3>;

  return(
    <div className="container mt-4">

      <div className="card p-4 shadow">

        <h3>Student Profile</h3>
        <p className="text-secondary">Academic & Personal Details</p>

        <hr/>

        <div className="row">

          {/* LEFT – Photo */}
          <div className="col-md-3 text-center">
            <img 
              src={s.photo || "https://via.placeholder.com/150"}
              alt="profile"
              style={{
                width:"150px",
                height:"150px",
                objectFit:"cover",
                borderRadius:"8px",
                border:"2px solid #0d6efd"
              }}
            />

            <h5 className="mt-3">{s.name}</h5>
            <p className="text-secondary">{s.reg_no}</p>
          </div>

          {/* RIGHT – Details */}
          <div className="col-md-9">

            <div className="row">

              <div className="col-md-6">
                <h6 className="text-primary">Academic Details</h6>
                <p><b>Department:</b> {s.dept}</p>
                <p><b>Year:</b> {s.year}</p>
                <p><b>Semester:</b> {s.semester}</p>
                <p><b>Admission Year:</b> {s.admission_year}</p>
              </div>

              <div className="col-md-6">
                <h6 className="text-primary">Personal Info</h6>
                <p><b>Gender:</b> {s.gender}</p>
                <p><b>DOB:</b> {s.dob}</p>
                <p><b>Blood Group:</b> {s.blood_group}</p>
              </div>

            </div>

            <hr/>

            <div className="row">

              <div className="col-md-6">
                <h6 className="text-primary">Contact</h6>
                <p><b>Phone:</b> {s.student_phone}</p>
                <p><b>Email:</b> {s.student_email}</p>
                <p><b>Address:</b> {s.address}</p>
              </div>

              <div className="col-md-6">
                <h6 className="text-primary">Parent Details</h6>
                <p><b>Father:</b> {s.father_name}</p>
                <p><b>Mother:</b> {s.mother_name}</p>
                <p><b>Parent Phone:</b> {s.parent_phone}</p>
              </div>

            </div>

          </div>

        </div>

      </div>

    </div>
  );
}
