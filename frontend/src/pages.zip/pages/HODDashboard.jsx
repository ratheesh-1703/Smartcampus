import { Link } from "react-router-dom";

export default function HODDashboard(){

  const user = JSON.parse(localStorage.getItem("user"));

  return (
    <div className="container mt-4">

      <h3>HOD Dashboard</h3>
      <p className="text-muted">
        Department Head Panel
      </p>

      <div className="row mt-4">

        <div className="col-md-4">
          <div className="card p-3 shadow">
            <h5>Teachers</h5>
            <Link to="/hod/teachers" className="btn btn-primary btn-sm">
              View Teachers
            </Link>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card p-3 shadow">
            <h5>Students</h5>
            <Link to="/hod/students" className="btn btn-success btn-sm">
              View Students
            </Link>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card p-3 shadow">
            <h5>Assign Coordinator</h5>
            <Link to="/hod/assign-coordinator" className="btn btn-warning btn-sm">
              Assign
            </Link>
          </div>
        </div>

        <div className="col-md-4 mt-3">
          <div className="card p-3 shadow">
            <h5>Attendance</h5>
            <Link to="/hod/attendance" className="btn btn-info btn-sm">
              View Attendance
            </Link>
          </div>
        </div>

      </div>
    </div>
  );
}
