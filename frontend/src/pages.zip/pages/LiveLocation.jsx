import { useEffect, useState } from "react";

export default function LiveLocation(){

  const [students,setStudents] = useState([]);

  const load = async ()=>{
    let res = await fetch("http://localhost/SmartCampus/backend/get_live_locations.php");
    let data = await res.json();
    if(data.status) setStudents(data.students);
  };

  useEffect(()=>{
    load();
    const i = setInterval(load, 5000);
    return ()=>clearInterval(i);
  },[]);

  return(
    <div className="container mt-4">
      <div className="card p-4 shadow">
        <h3>Campus Live Location</h3>

        <table className="table table-bordered">
          <thead>
            <tr>
              <th>Reg No</th>
              <th>Name</th>
              <th>Dept</th>
              <th>Map</th>
              <th>Last Seen</th>
            </tr>
          </thead>

          <tbody>
            {students.map((s,i)=>(
              <tr key={i}>
                <td>{s.reg_no}</td>
                <td>{s.name}</td>
                <td>{s.dept}</td>
                <td>
                  <a
                    target="_blank"
                    href={`https://www.google.com/maps?q=${s.latitude},${s.longitude}`}
                  >
                    View
                  </a>
                </td>
                <td>{s.last_seen}</td>
              </tr>
            ))}

            {students.length===0 &&
              <tr>
                <td colSpan="5" className="text-center">
                  No students online
                </td>
              </tr>
            }
          </tbody>
        </table>

      </div>
    </div>
  );
}
