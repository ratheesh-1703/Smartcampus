import { useState } from "react";

export default function AddStudent(){

  const [student,setStudent] = useState({
    name:"",
    reg_no:"",
    dept:"",
    year:"",
    parent_phone:""
  });

  const handleChange = (e) =>{
    setStudent({...student, [e.target.name]:e.target.value});
  }

  const saveStudent = async () =>{
    let res = await fetch("http://localhost/SmartCampus/backend/add_student.php",{
      method:"POST",
      headers:{ "Content-Type":"application/json"},
      body: JSON.stringify(student)
    });

    let data = await res.json();
    alert(data.message);
  }

  return(
    <div className="container mt-4">
      <h3>Add Student</h3>

      <div className="card p-4 shadow">

        <input className="form-control mb-3"
          placeholder="Student Name"
          name="name"
          onChange={handleChange}
        />

        <input className="form-control mb-3"
          placeholder="Register Number"
          name="reg_no"
          onChange={handleChange}
        />

        <input className="form-control mb-3"
          placeholder="Department"
          name="dept"
          onChange={handleChange}
        />

        <input className="form-control mb-3"
          placeholder="Year"
          name="year"
          onChange={handleChange}
        />

        <input className="form-control mb-3"
          placeholder="Parent Phone"
          name="parent_phone"
          onChange={handleChange}
        />

        <button className="btn btn-primary" onClick={saveStudent}>
          Save Student
        </button>

      </div>
    </div>
  );
}
