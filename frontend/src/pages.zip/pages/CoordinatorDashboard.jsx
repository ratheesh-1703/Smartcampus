import { Link } from "react-router-dom";

export default function CoordinatorDashboard(){

  const user = JSON.parse(localStorage.getItem("user"));

  return (
    <div className="container mt-4">
      <h3>Coordinator Dashboard</h3>

      <p>
        Assigned Class: 
        <b className="text-primary"> {user.assigned_class}</b>
      </p>

      <div className="row mt-4">

        <div className="col-md-4">
          <Link to="/coordinator/students" className="card p-3 shadow text-decoration-none">
            <h5>👥 Students</h5>
            <p>View class students</p>
          </Link>
        </div>

        <div className="col-md-4">
          <Link to="/coordinator/attendance" className="card p-3 shadow text-decoration-none">
            <h5>📝 Attendance</h5>
            <p>Mark attendance</p>
          </Link>
        </div>

        <div className="col-md-4">
          <Link to="/coordinator/history" className="card p-3 shadow text-decoration-none">
            <h5>📊 Attendance History</h5>
            <p>View past records</p>
          </Link>
        </div>

      </div>
    </div>
  );
}
