import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

export default function AdminDashboard() {

  const [counts, setCounts] = useState({
    students: 0,
    teachers: 0,
    sos: 0
  });

  useEffect(() => {
    loadCounts();
  }, []);

  const loadCounts = async () => {
    try{
      let res = await fetch("http://localhost/SmartCampus/backend/admin_counts.php");
      let data = await res.json();

      if (data.status) {
        setCounts({
          students: data.students,
          teachers: data.teachers,
          sos: data.sos
        });
      }

    }catch(err){
      console.log("Admin Count Error:", err);
    }
  };

  return (
    <div className="d-flex" style={{ height: "100vh" }}>

      {/* Sidebar */}
      <div
        style={{
          width: "260px",
          background: "#0c2d6b",
          color: "white",
          padding: "15px"
        }}
      >
        <h4 className="text-center mb-4">Smart Campus</h4>

        <ul className="nav flex-column gap-2">

          <li className="nav-item">
            <Link className="nav-link text-white" to="/admin">
              <i className="bi bi-speedometer2 me-2"></i>
              Dashboard
            </Link>
          </li>

          <li className="nav-item">
            <Link className="nav-link text-white" to="/admin/addstudent">
              <i className="bi bi-person-plus me-2"></i>
              Add Student
            </Link>
          </li>

          <li className="nav-item">
            <Link className="nav-link text-white" to="/admin/importstudents">
              <i className="bi bi-upload me-2"></i>
              Import Students (Bulk)
            </Link>
          </li>

          <li className="nav-item">
            <Link className="nav-link text-white" to="/admin/students">
              <i className="bi bi-list-ul me-2"></i>
              View Students
            </Link>
          </li>

          {/* Assign HOD */}
          <li className="nav-item">
  <a className="nav-link text-white" href="/admin/assign-hod">
    <i className="bi bi-person-badge me-2"></i>
    Assign HOD
  </a>
</li>


          {/* Import Teachers */}
          <li className="nav-item">
  <a className="nav-link text-white" href="/admin/importteachers">
    <i className="bi bi-upload me-2"></i>
    Import Teachers (Bulk)
  </a>
</li>


          <li className="nav-item">
            <span className="nav-link text-white">
              <i className="bi bi-shield-check me-2"></i>
              Attendance Control
            </span>
          </li>

          <li className="nav-item">
 <a className="nav-link text-white" href="/admin/livelocation">
  <i className="bi bi-geo-alt me-2"></i>
  Live Location
</a>

</li>


          <li className="nav-item">
            <span className="nav-link text-white">
              <i className="bi bi-bell me-2"></i>
              SOS Alerts
            </span>
          </li>

          <li className="nav-item mt-3">
            <a className="btn btn-danger w-100" href="/">
              Logout
            </a>
          </li>

        </ul>
      </div>

      {/* Main Section */}
      <div className="flex-grow-1">

        {/* Top Bar */}
        <div
          className="p-3"
          style={{ background: "#0d6efd", color: "white" }}
        >
          <h5 className="m-0">Admin Dashboard</h5>
        </div>

        {/* Page Content */}
        <div className="p-4">

          <div className="row">

            <div className="col-md-4">
              <div className="card p-3 shadow">
                <h5>Total Students</h5>
                <h2>{counts.students}</h2>
              </div>
            </div>

            <div className="col-md-4">
              <div className="card p-3 shadow">
                <h5>Total Teachers</h5>
                <h2>{counts.teachers}</h2>
              </div>
            </div>

            <div className="col-md-4">
              <div className="card p-3 shadow">
                <h5>Active SOS Alerts</h5>
                <h2>{counts.sos}</h2>
              </div>
            </div>

          </div>

          <div className="card mt-4 p-4 shadow">
            <h4>Welcome Admin</h4>
            <p>This panel will control the entire Smart Campus System.</p>
          </div>

        </div>

      </div>
    </div>
  );
}
