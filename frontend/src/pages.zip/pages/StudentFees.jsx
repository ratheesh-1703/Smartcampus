import { useEffect, useState } from "react";

export default function StudentFees(){

  const student_id = 1;

  const [summary,setSummary] = useState({
    total:0,
    paid:0,
    pending:0
  });

  const [fees,setFees] = useState([]);
  const [loading,setLoading] = useState(true);

  const loadFees = async ()=>{
    try{
      let res = await fetch(
        `http://localhost/SmartCampus/backend/get_student_fees.php?student_id=${student_id}`
      );

      let data = await res.json();

      if(data.status){
        setSummary(data.summary);
        setFees(data.fees);
      }

    }catch(e){
      console.log("FEES ERROR:",e);
    }

    setLoading(false);
  };

  useEffect(()=>{ loadFees(); },[]);

  return(
    <div className="container mt-4">

      <div className="card p-4 shadow">

        <h3>Fees & Payments</h3>
        <p className="text-secondary">View your outstanding & paid fee details</p>

        <hr/>

        {loading && <h5>Loading...</h5>}

        {!loading && (
          <>
            {/* SUMMARY CARDS */}
            <div className="row text-center mb-4">

              <div className="col-md-4">
                <div className="card p-3 shadow">
                  <h6>Total Fees</h6>
                  <h2>₹{summary.total}</h2>
                </div>
              </div>

              <div className="col-md-4">
                <div className="card p-3 shadow text-success">
                  <h6>Paid</h6>
                  <h2>₹{summary.paid}</h2>
                </div>
              </div>

              <div className="col-md-4">
                <div className="card p-3 shadow text-danger">
                  <h6>Pending</h6>
                  <h2>₹{summary.pending}</h2>
                </div>
              </div>

            </div>

            {/* TABLE */}
            <table className="table table-bordered">
              <thead style={{background:"#0d6efd", color:"white"}}>
                <tr>
                  <th>Semester</th>
                  <th>Fee Type</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th>Paid On</th>
                  <th>Receipt</th>
                </tr>
              </thead>

              <tbody>

                {fees.map((f,i)=>(
                  <tr key={i}>
                    <td>{f.semester}</td>
                    <td>{f.type}</td>
                    <td>₹{f.amount}</td>

                    <td className={f.status==="Paid" ? "text-success" : "text-danger"}>
                      <b>{f.status}</b>
                    </td>

                    <td>{f.paid_date || "-"}</td>

                    <td>
                      {f.status === "Paid" ?
                        <a 
                          className="btn btn-primary btn-sm"
                          href={`http://localhost/SmartCampus/backend/receipts/${f.receipt}`}
                          target="_blank"
                        >
                          Download
                        </a>
                        :
                        "-"
                      }
                    </td>
                  </tr>
                ))}

                {fees.length===0 && (
                  <tr>
                    <td colSpan="6" className="text-center">
                      No Fee Records Found
                    </td>
                  </tr>
                )}

              </tbody>
            </table>

          </>
        )}

      </div>

    </div>
  );
}
