import { useEffect, useState } from "react";

export default function CoordinatorStudents() {

  const user = JSON.parse(localStorage.getItem("user"));
  const coordinator_id = user?.linked_id;

  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadStudents = async () => {
    try {
      const res = await fetch(
        `http://localhost/SmartCampus/backend/get_coordinator_students.php?coordinator_id=${coordinator_id}`
      );
      const data = await res.json();

      if (data.status) {
        setStudents(data.students);
      }
    } catch (err) {
      console.error(err);
    }

    setLoading(false);
  };

  useEffect(() => {
    if (coordinator_id) {
      loadStudents();
    }
  }, [coordinator_id]);

  return (
    <div className="container mt-4">
      <h3>Assigned Students</h3>

      {loading ? (
        <p>Loading students...</p>
      ) : students.length === 0 ? (
        <p className="text-muted">No students assigned</p>
      ) : (
        <table className="table table-bordered mt-3">
          <thead className="table-dark">
            <tr>
              <th>Register No</th>
              <th>Name</th>
              <th>Department</th>
              <th>Year</th>
            </tr>
          </thead>
          <tbody>
            {students.map((s) => (
              <tr key={s.id}>
                <td>{s.reg_no}</td>
                <td>{s.name}</td>
                <td>{s.dept}</td>
                <td>{s.year}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
