import { useEffect, useState } from "react";

export default function HODTeachers() {
  const [teachers, setTeachers] = useState([]);

  useEffect(() => {
    fetch("http://localhost/SmartCampus/backend/get_teachers.php")
      .then(res => res.json())
      .then(data => {
        if (data.status) setTeachers(data.teachers);
      });
  }, []);

  return (
    <div className="container mt-4">
      <h3>Department Teachers</h3>

      <table className="table table-bordered mt-3">
        <thead className="table-dark">
          <tr>
            <th>Name</th>
            <th>Staff ID</th>
            <th>Role</th>
          </tr>
        </thead>
        <tbody>
          {teachers.map(t => (
            <tr key={t.id}>
              <td>{t.name}</td>
              <td>{t.staff_id}</td>
              <td>{t.is_hod === "1" ? "HOD" : "Teacher"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
