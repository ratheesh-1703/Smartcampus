import { useEffect, useState } from "react";

export default function StudentMarks(){

  const student_id = 1;   // later dynamic from login
  const [courses,setCourses] = useState([]);
  const [loading,setLoading] = useState(true);
  const [expanded,setExpanded] = useState(null);

  const loadMarks = async () => {
  try{
    const res = await fetch(
      `http://localhost/SmartCampus/backend/get_student_marks.php?student_id=${student_id}`
    );
    const data = await res.json();
    if(data.status) setMarks(data.marks);
  }catch(err){
    console.error("MARKS FETCH ERROR", err);
  }
};


  useEffect(()=>{ loadMarks(); },[]);

  return(
    <div className="container mt-4">
      
      <div className="card p-4 shadow">

        <h3>Marks Details</h3>
        <p className="text-secondary">
          Internal & Assessment marks for each registered course
        </p>

        <hr/>

        {loading && <h5>Loading...</h5>}

        {!loading && (
          <table className="table table-bordered table-striped">
            <thead style={{background:"#0d6efd",color:"white"}}>
              <tr>
                <th>#</th>
                <th>Course Code</th>
                <th>Course Name</th>
                <th>Total Marks</th>
                <th>View</th>
              </tr>
            </thead>

            <tbody>

              {courses.map((c,i)=>(
                <>
                  {/* MAIN ROW */}
                  <tr key={i}>
                    <td>{i+1}</td>
                    <td>{c.course_code}</td>
                    <td>{c.course_name}</td>
                    <td><b>{c.total || "-"}</b></td>

                    <td>
                      <button 
                        className="btn btn-primary btn-sm"
                        onClick={()=> setExpanded(expanded === i ? null : i)}
                      >
                        {expanded === i ? "Hide" : "View"}
                      </button>
                    </td>
                  </tr>

                  {/* EXPANDED MARK TABLE */}
                  {expanded === i && (
                    <tr>
                      <td colSpan="5">
                        <table className="table table-bordered mb-0">
                          <thead className="table-light">
                            <tr>
                              <th>S.No</th>
                              <th>Assessment</th>
                              <th>Marks</th>
                            </tr>
                          </thead>

                          <tbody>
                            {c.assessments.map((m,idx)=>(
                              <tr key={idx}>
                                <td>{idx+1}</td>
                                <td>{m.title}</td>
                                <td><b>{m.marks}</b></td>
                              </tr>
                            ))}

                            {c.assessments.length === 0 && (
                              <tr>
                                <td colSpan="3" className="text-center">
                                  No Marks Uploaded
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </td>
                    </tr>
                  )}

                </>
              ))}

              {courses.length === 0 && (
                <tr>
                  <td colSpan="5" className="text-center">
                    No Marks Found
                  </td>
                </tr>
              )}

            </tbody>
          </table>
        )}

      </div>
    </div>
  );
}
