import { useState } from "react";

export default function StudentSOS() {

  const user = JSON.parse(localStorage.getItem("user"));
  const student_id = user?.linked_id;   // IMPORTANT

  const [message, setMessage] = useState("");
  const [photo, setPhoto] = useState(null);

  const sendSOS = async ()=>{

    if(!student_id){
      alert("Student ID Not Found — Login Again");
      return;
    }

    if(message.trim() === ""){
      alert("Enter SOS message");
      return;
    }

    let form = new FormData();
    form.append("student_id", student_id);
    form.append("message", message);

    if(photo){
      form.append("photo", photo);
    }

    let res = await fetch("http://localhost/SmartCampus/backend/send_sos.php",{
      method:"POST",
      body: form
    });

    let data = await res.json();
    console.log("SOS RESPONSE",data);

    alert(data.message);
  };

  return(
    <div className="container mt-4">
      <div className="card p-4 shadow">

        <h2>Emergency SOS</h2>
        <p>If you are in danger, raise SOS immediately.</p>

        <textarea 
          className="form-control"
          rows={3}
          placeholder="Explain your problem"
          value={message}
          onChange={e=>setMessage(e.target.value)}
        />

        <label className="mt-3">Upload Photo Evidence (Optional)</label>
        <input 
          type="file"
          className="form-control"
          onChange={(e)=>setPhoto(e.target.files[0])}
        />

        <button 
          className="btn btn-danger mt-3 w-100"
          onClick={sendSOS}
        >
          🚨 Send SOS Alert
        </button>

      </div>
    </div>
  );
}
