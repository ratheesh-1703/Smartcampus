import { useEffect, useState } from "react";

export default function CoordinatorAttendance() {

  const user = JSON.parse(localStorage.getItem("user"));
  const coordinator_id = user?.linked_id;

  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadAttendance = async () => {
    try {
      const res = await fetch(
        `http://localhost/SmartCampus/backend/get_coordinator_attendance.php?coordinator_id=${coordinator_id}`
      );
      const data = await res.json();

      if (data.status) {
        setRecords(data.records);
      }
    } catch (err) {
      console.error(err);
    }

    setLoading(false);
  };

  useEffect(() => {
    if (coordinator_id) {
      loadAttendance();
    }
  }, [coordinator_id]);

  return (
    <div className="container mt-4">
      <h3>Attendance Records</h3>

      {loading ? (
        <p>Loading attendance...</p>
      ) : records.length === 0 ? (
        <p className="text-muted">No attendance records found</p>
      ) : (
        <table className="table table-bordered mt-3">
          <thead className="table-dark">
            <tr>
              <th>Register No</th>
              <th>Name</th>
              <th>Date</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {records.map((r) => (
              <tr key={r.id}>
                <td>{r.reg_no}</td>
                <td>{r.student_name}</td>
                <td>{r.date}</td>
                <td>
                  {r.status === "present" ? (
                    <span className="badge bg-success">Present</span>
                  ) : (
                    <span className="badge bg-danger">Absent</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
