import { useEffect, useState } from "react";

export default function TeacherAttendance(){

  // ================= LOGIN SESSION CHECK =================
  const savedUser = localStorage.getItem("user");

  if(!savedUser){
    alert("Session expired. Please login again.");
    window.location.href = "/";
  }

  const user = JSON.parse(savedUser);

  if(user.role !== "teacher"){
    alert("Unauthorized! Only teachers allowed.");
    window.location.href = "/";
  }

  const teacher_id = user.user_id;


  // ================= STATES =================
  const [session,setSession] = useState(null);
  const [students,setStudents] = useState([]);
  const [absent,setAbsent] = useState([]);
  const [msg,setMsg] = useState("");

  const [summary,setSummary] = useState({
    total:0,
    present:0,
    absent:0,
    percentage:0
  });

  const [courses,setCourses] = useState([]);
  const [sel,setSel] = useState("");


  // ================= LOAD COURSES =================
  const loadCourses = async ()=>{
    let res = await fetch(
      `http://localhost/SmartCampus/backend/get_teacher_courses.php?teacher_id=${teacher_id}`
    );

    let data = await res.json();
    if(data.status) setCourses(data.courses);
  };


  // ================= LOAD ACTIVE SESSION =================
  const loadSession = async ()=>{
    let res = await fetch(
      `http://localhost/SmartCampus/backend/get_active_teacher_session.php?teacher_id=${teacher_id}`
    );

    let data = await res.json();

    if(data.status){
      setSession(data.session);
      loadStudents(data.session.id);
      loadSummary(data.session.id);
      loadAbsent(data.session.id);
      setMsg("");
    } else {
      setSession(null);
      setStudents([]);
      setAbsent([]);
      setMsg("No Active Attendance Session");
    }
  };


  // ================= PRESENT STUDENTS =================
  const loadStudents = async (sid)=>{
    let res = await fetch(
      `http://localhost/SmartCampus/backend/get_attendance_list.php?session_id=${sid}`
    );
    let data = await res.json();
    if(data.status) setStudents(data.students);
  };


  // ================= SUMMARY =================
  const loadSummary = async (sid)=>{
    let res = await fetch(
      `http://localhost/SmartCampus/backend/get_attendance_summary.php?session_id=${sid}`
    );
    let data = await res.json();
    if(data.status) setSummary(data);
  };


  // ================= ABSENT STUDENTS =================
  const loadAbsent = async (sid)=>{
    let res = await fetch(
      `http://localhost/SmartCampus/backend/get_absent_students.php?session_id=${sid}`
    );
    let data = await res.json();
    if(data.status) setAbsent(data.absent);
  };


  // ================= AUTO REFRESH =================
  useEffect(()=>{
    loadSession();
    loadCourses();

    const i = setInterval(()=>{
      if(session){
        loadStudents(session.id);
        loadSummary(session.id);
        loadAbsent(session.id);
      } else {
        loadSession();
      }
    },5000);

    return ()=>clearInterval(i);
  },[session]);


  // ================= START SESSION =================
  const startSession = async ()=>{

    if(!sel){
      alert("Select a class to start attendance");
      return;
    }

    const c = JSON.parse(sel);

    let res = await fetch(
      "http://localhost/SmartCampus/backend/start_attendance.php",
      {
        method:"POST",
        headers:{ "Content-Type":"application/json"},
        body: JSON.stringify({
          teacher_id,
          subject: c.subject,
          dept: c.dept,
          year: c.year,
          section: c.section
        })
      }
    );

    let data = await res.json();
    alert(data.message);
    loadSession();
  };


  // ================= END SESSION =================
  const endSession = async ()=>{
    if(!window.confirm("End Attendance Session?")) return;

    let res = await fetch(
      `http://10.43.165.203/SmartCampus/backend/end_attendance.php?teacher_id=${teacher_id}`
    );

    let data = await res.json();
    alert(data.message);
    loadSession();
  };


  return(
    <div className="container mt-4">
      <div className="card p-4 shadow">

        <h3>Teacher Attendance Control</h3>


        {/* NO SESSION */}
        {!session && (
          <>
            <p className="text-danger">{msg}</p>

            <select 
              className="form-control w-50"
              onChange={e=>setSel(e.target.value)}
            >
              <option>Select Class</option>

              {courses.map((c,i)=>(
                <option key={i} value={JSON.stringify(c)}>
                  {c.dept} | Year {c.year} | Sec {c.section} | {c.subject}
                </option>
              ))}
            </select>

            <button className="btn btn-primary mt-3" onClick={startSession}>
              Start Attendance
            </button>
          </>
        )}


        {/* ACTIVE SESSION */}
        {session && (
          <>
            <div className="d-flex justify-content-between">
              <div>
                <p><b>Subject:</b> {session.subject}</p>
                <p><b>Department:</b> {session.dept} | Year {session.year} | {session.section}</p>
                <p><b>Started:</b> {session.started_at}</p>
                <p><b>Gateway:</b> {session.gateway_ip}</p>
              </div>

              <button className="btn btn-danger" onClick={endSession}>
                End Session
              </button>
            </div>

            <hr/>


            {/* SUMMARY */}
            <div className="row text-center mb-3">

              <div className="col-md-3">
                <div className="card p-3 shadow">
                  <h6>Total Students</h6>
                  <h2>{summary.total}</h2>
                </div>
              </div>

              <div className="col-md-3">
                <div className="card p-3 shadow text-success">
                  <h6>Present</h6>
                  <h2>{summary.present}</h2>
                </div>
              </div>

              <div className="col-md-3">
                <div className="card p-3 shadow text-danger">
                  <h6>Absent</h6>
                  <h2>{summary.absent}</h2>
                </div>
              </div>

              <div className="col-md-3">
                <div className="card p-3 shadow text-primary">
                  <h6>Percentage</h6>
                  <h2>{summary.percentage}%</h2>
                </div>
              </div>

            </div>

            <hr/>


            {/* PRESENT */}
            <h5>Students Marked Present ({students.length})</h5>

            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>Reg No</th>
                  <th>Name</th>
                  <th>Dept</th>
                  <th>Marked Time</th>
                </tr>
              </thead>

              <tbody>
                {students.map((s,i)=>(
                  <tr key={i}>
                    <td>{s.reg_no}</td>
                    <td>{s.name}</td>
                    <td>{s.dept}</td>
                    <td>{s.marked_at}</td>
                  </tr>
                ))}

                {students.length === 0 && (
                  <tr>
                    <td colSpan="4" className="text-center">
                      No students yet...
                    </td>
                  </tr>
                )}
              </tbody>
            </table>


            <hr/>


            {/* ABSENT */}
            <h5 className="text-danger">Absent Students ({absent.length})</h5>

            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>Reg No</th>
                  <th>Name</th>
                  <th>Dept</th>
                </tr>
              </thead>

              <tbody>

                {absent.map((s,i)=>(
                  <tr key={i}>
                    <td>{s.reg_no}</td>
                    <td>{s.name}</td>
                    <td>{s.dept}</td>
                  </tr>
                ))}

                {absent.length === 0 && (
                  <tr>
                    <td colSpan="3" className="text-center">
                      All Students Present 🎉
                    </td>
                  </tr>
                )}

              </tbody>
            </table>
          </>
        )}

      </div>
    </div>
  );
}
